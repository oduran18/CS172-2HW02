/////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS-172-2
//Matthew Bell
//2/25/16
/////////////////////////////////////////////////////////////////////////////
#include <iostream>

using namespace std;

 //int getValue(int &value);
class EvenNumber // Class name.
{
private: //Private aspects of class.
    int value = 0;
    int next = 0;
    int previous = 0;

public: // Public aspects of class.
    EvenNumber() // No arg constructor.
    {
        value = 0;
    }
    EvenNumber (int value); // Constructor with the purpose to create object with specified value... Having trouble trying to understand what is asking for.

    int getValue(int &value) // Function of type int with purpose to get a value from the user.
    {
        return value;
    }
    int getNext(int &next) // Function with the purpose to get the next even value from the user.
    {
        next = value + 2;
        return next;
    }
    int getPrevious(int previous) // Function with the purpose to get the previous even value of the function.
    {
        previous = value - 2;
        return previous;
    }
};

int main() // Main function with class and function calls, Having trouble calling the functions from class to main in order to use them.
{
    //int o = getValue();
   // EvenNumber.getPrevious(previous)
    //previous.getPrevious(previous);
    //int previous = 0;
    //int previous = 0;
    EvenNumber evennumber;
    int previous = evennumber.getPrevious(previous);
    int next = 0;
    //EvenNumber next;
    //next.getNext();
    //EvenNumber valuex;
    //valuex.getValue();
    //int value = 0;
    cout << "Enter a number value: ";
    cin >> value;
    if(value % 2 !=0)
    {
        cout << value << " Is not even." << endl;
    }
    else if(value % 2 == 0)
    {
         //getValue(value);
         cout << "Number is even. " << value << endl;

         EvenNumber evenumber;
         cout << "Next even Number is: " << evenumber.getNext(next) << endl;

         //EvenNumber evennumber;
         cout << "The previous even number is: " << evennumber.getPrevious(previous) << endl;
    }


    return 0;
}
