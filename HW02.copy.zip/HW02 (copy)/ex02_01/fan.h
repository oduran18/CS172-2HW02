#ifndef FAN_H_INCLUDED
#define FAN_H_INCLUDED

int getSpeed();
void setSpeed(int speed);
bool isOn();
void setOn();
double getRadius();
void setRadius();
//string getColor();
void setColor();

#endif // FAN_H_INCLUDED
