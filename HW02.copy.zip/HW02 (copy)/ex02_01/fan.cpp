#include <iostream>
#include <string>
#include "fan.h"

using namespace std;

class Fan
{
public:
  Fan()
  {
    speed = 1;
    on = false;
    radius = 5;
    color = string("white");
  }

  int getSpeed()
  {
    return speed;
  }

  void setSpeed(int speed)
  {
    this->speed = speed;
  }

  bool isOn()
  {
    return on;
  }

  void setOn(bool trueOrFalse)
  {
    this->on = trueOrFalse;
  }

  double getRadius()
  {
    return radius;
  }

  void setRadius(double radius)
  {
    this->radius = radius;
  }

  string getColor()
  {
    return color;
  }

  void setColor(string color)
  {
    this->color = color;
  }

private:
  int speed;
  bool on;
  double radius;
  string color;
};

