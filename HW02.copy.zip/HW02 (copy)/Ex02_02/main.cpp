///////////////////////////////////////////////////////////////////
//Oscar Duran
//CS-172-2
//Matthew Bell
//2/15/16
///////////////////////////////////////////////////////////////////
#include <iostream>
#include <cmath>
#include "QuadraticEquations.h"
using namespace std;

class QuadraticEquation // Class with the information for the quadratic formula.
{
private: // Private aspects of the class
  int a;
  int b;
  int c;

public: // Pubic aspects of the class.
  QuadraticEquation(double a, double b, double c)
    : a(a), b(b), c(c)
  {
  }


//From here on all the variables will be of the type double to avoid errors regarding decimal number division and reminders, also to avoid conversion later on.
  double getA() //Function of get A.
  {
    return a;
  }

  double getB() //Function to get B.
  {
    return b;
  }

  double getC() //Function to get C.
  {
    return c;
  }

  double getDiscriminant() // Function for the discriminant.
  {
    return b * b - 4 * a * c;
  }

  double getRoot1() // Function to get the root of first number.
  {
    if (getDiscriminant() < 0)
      return 0;
    else
    {
      return (-b + sqrt(getDiscriminant())) / (2 * a);
    }
  }

  double getRoot2() // Function to get root of second number.
  {
    if (getDiscriminant() < 0)
      return 0;
    else
    {
      return (-b - sqrt(getDiscriminant())) / (2 * a);
    }
  }
};

int main() // Main Function, with the class and function calls.
{
  cout << "Enter a, b, c: ";
  double a, b, c, discriminant, r1, r2;
  cin >> a >> b >> c;

  QuadraticEquation equation(a, b, c);
  discriminant = equation.getDiscriminant();

  // Chain of if else statements to control if the numbers have a root or not.
  if (discriminant < 0)
  {
    cout << "The equation has no roots" << endl;
  }
  else if (discriminant == 0)
  {
    cout << "The root is " << equation.getRoot1() << endl;
  }
  else // (discriminant >= 0)
  {
     cout << "The roots are " << equation.getRoot1() << " and "
       << equation.getRoot2() << endl;
  }

  return 0;
}
