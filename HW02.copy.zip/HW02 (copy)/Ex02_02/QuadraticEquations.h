#ifndef FAN_H_INCLUDED
#define FAN_H_INCLUDED
double getA();
double getB();
double getC();
double getDiscriminant();
double getRoot1();
double getRoot2();

#endif // FAN_H_INCLUDED

