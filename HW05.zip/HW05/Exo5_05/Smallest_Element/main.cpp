#include <iostream>
//#include <cstdlib>

using namespace std;

int* find_smallest_number(int *random_array, int size)
{
    int* minPtr = random_array;
    for(int i = 1; i < size; i++)
    {
        if ( *(random_array + i) < *minPtr )
           minPtr = random_array + i;
    }
    return minPtr;
}

int main()

{
    const int size = 10;
    int random_array[size] = {1,2,4,5,10,100,2,-22};

    int* smallestNumber = find_smallest_number(random_array, size);

    //srand(time(NULL));

    for(int i = 0; i < size; i++)
    {
        //*(random_array + i) = rand()%1410;
        cout << random_array[i] << endl;
        //cout << &*(random_array + i) << endl;
    }

    cout << "The smallest number is " << *smallestNumber << endl;

    return 0;
}
