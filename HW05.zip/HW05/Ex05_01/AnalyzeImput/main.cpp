#include <iostream>

using namespace std;

int main()
{
const int size = 5;
double num_array[] = {2,2,3,4,5};
double* a = num_array;
cout << average(a,size);
cout << endl;
return 0;
}

double average(double* a,const int size)
{
double total = 0;
for (int count =0; count< size; count++){
    total = total + *(a + count);
}
return total/size;
}
