////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-2 Test 1
//Matthew Bell
//3/4/2016
//I affirm that all code given below was written solely by me, Oscar Duran, and that any help I received adhered to the rules stated for this exam.
//////////////////////////////////////////////////////////////////////////////////////////
#ifndef _VENUE_H_
//This .h file has the class and function headers for my Venue class.
using namespace std;
class Venue
{
private: //Private aspects of class

    Event scheduledEvents[12];
    int numEvents = 0;
    bool validTime(int Time);

public: // Public aspects of function

    void addEvent(int time);
    void addEvent(string name);
    Event findEvent(int time);
    Event findEvent(string name);

};
#endif // _VENUE_H_
