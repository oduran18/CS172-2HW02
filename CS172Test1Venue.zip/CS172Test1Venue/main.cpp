////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-2 Test 1
//Matthew Bell
//3/4/2016
//I affirm that all code given below was written solely by me, Oscar Duran, and that any help I received adhered to the rules stated for this exam.
//////////////////////////////////////////////////////////////////////////////////////////
//This main.cpp file was provided by the professor Matthew Bell
#include <iostream>
#include <string>
#include "Event.h"
#include "Venue.h"

using namespace std;

int main()
{
	Venue theSpot;
	theSpot.addEvent(10);    //Should work
	theSpot.addEvent("Coffee Hour");
	theSpot.addEvent(11);  //Should work
	theSpot.addEvent("Brunch w/ Bob");
	theSpot.addEvent(11); //Shouldn't work
	theSpot.addEvent("Bingo");

	cout << theSpot.findEvent(10).getTtitle() << endl; //Should find Coffee Hour
	cout << theSpot.findEvent("Brunch w/ Bob").getTime() << endl;  //Should find 11 o'clock
	cout << theSpot.findEvent("Bingo").getTime() << endl; //Should print -1, because Bingo ain't there!

	return 0;
}
