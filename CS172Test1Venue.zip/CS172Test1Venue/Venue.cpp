////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-2 Test 1
//Matthew Bell
//3/4/2016
//I affirm that all code given below was written solely by me, Oscar Duran, and that any help I received adhered to the rules stated for this exam.
//////////////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <string>
#include "Event.h"
#include "Venue.h"

using namespace std;
// In this c.pp file are the definition of the Function within my Venue class.

void Venue::addEvent(int time) // Function to add event and save it into an array of 12. Still having problems, it is giving me errors, that i can't figure out.
{
    for (int i = 0; i < 12; i++) //loop to control what goes into the array
    {
        scheduledEvents[i].getTime();
        Event Venue::findEvent(int time) // This function was supposed to call the scheduled events, but it is giving me errors.
        {
            cout << scheduledEvents[i].getTime() << endl;
        }
    }
}

void Venue::addEvent(string name) //loop to control what goes into the array
{
    for (int i = 0; i < 12; i++)
    {
        scheduledEvents[i].getTtitle();
        Event Venue::findEvent(string name) // This function was supposed to call the scheduled events, but it is giving me errors.
        {
            cout << scheduledEvents[i].getTtitle() << endl;
        }
    }
}

//This code here is not important, i had it there in case i need to use it.
//Event Venue::findEvent(int time)
//{
  //  cout << scheduledEvents[i].getTime() << endl;
//}

//Event Venue::findEvent(string name)
//{
  //  cout << scheduledEvents[name].getTtitle() << endl;
//}
