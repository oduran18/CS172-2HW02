////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-2 Test 1
//Matthew Bell
//3/4/2016
//I affirm that all code given below was written solely by me, Oscar Duran, and that any help I received adhered to the rules stated for this exam.
//////////////////////////////////////////////////////////////////////////////////////////
#ifndef _EVENT_H_
//this .h file has the class and function headers for my Event class.
using namespace std;
class Event // class name
{
private: //Private aspects of class
    int time;
    string Title;

public: // Public aspects of function
    Event(int time, string name);
    Event();
    int getTime();
    string getTtitle();
    void setTime(int t);
    void setTitile(string name);
};
#endif // _EVENT_H_
