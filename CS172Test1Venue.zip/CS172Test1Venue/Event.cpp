////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-2 Test 1
//Matthew Bell
//3/4/2016
//I affirm that all code given below was written solely by me, Oscar Duran, and that any help I received adhered to the rules stated for this exam.
//////////////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <string>
#include "Event.h"
#include "Venue.h"


using namespace std;
//This .cpp file contains the definitions for the functions within my Event class.

Event::Event(int time, string name)
{
    time = 0;
    name = Title;
}

Event::Event() // Constructor for default
{
    time = -1;
    Title = "free";
}

int Event::getTime() // Function to get time of event
{
    cout << "Please enter the time for your event: ";
    cin >> time;

    return time;
}

string Event::getTtitle() // Function to get name of event
{
    cout << "Please enter the name of your event: ";
    cin >> Title;

    //return Title;
}

void Event::setTime(int t) // Function to set the time of event
{
    time = t;
}

 void Event::setTitile(string name) // Function to set the name of event
 {
     Title = name;
 }
