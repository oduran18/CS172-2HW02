/////////////////////////////////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-1
//Matthew Bell
//3/15/16
/////////////////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout << "Enter a string: "; //Prompts the user to enter a string.
    string s; // string type variable declared, what the user inputs will be saved here.
    getline(cin,s); // Gets the string from the user.

    int low = 0; // int type variable declared. Index of first character in string.

    int high = s.length() - 1; // index of last character on string.
    bool isPalindrome = true; //bool type variable to check if string is palindrome.
    while (low < high) // Loop to reverse and check for palindrome.
    {
        if (s[low] != s[high]) // if statement checking if the index of first character equals the index of last character
        {
            isPalindrome = false;
            break;
        }

        low ++;//reverse word by incrementing low by one.
        high --; // reverse word by decreasing high by one.
    }

    if (isPalindrome) // Checking to see if it is palindrome.
        cout << s << " is a palindrome" << endl; // if word is palindrome this message appears
    else
        cout << s << " is not a palindrome" << endl; // if word is not palindrome, second message appears.

    return 0;
}
