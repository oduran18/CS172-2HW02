#ifndef _REGULARPOLYGON_H_
class RegularPolygon // Class declaration
{
private: // Private aspects of functions.
    int n = 0;
    double side = 0;
    double x = 0;
    double y = 0;
public: // Public aspects of functions.
    RegularPolygon(); //constructor for default polygon
    RegularPolygon(int& o, double & s); // constructor with set coordinates, the user inputs number of sides and length of sides
    RegularPolygon(int& o, double& s, double& c, double& u);// Constructor which lets the user input number of sides, length of sides, and x and y coordinates
    int getPerimeter(int& o, double& s); // function with purpose of getting perimeter for function, i had an error with this one so it does not work.
    int getArea(int& o, double& s); // Function with purpose to get area of polygon, still working on this, not able to make it work


};
#endif // _REGULARPOLYGON_H_
