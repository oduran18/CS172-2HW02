///////////////////////////////////////////////////////////////////
//Oscar Duran
//CS172-1
//Matthew Bell
//3/15/16
///////////////////////////////////////////////////////////////////
#include <iostream>
#include "RegularPolygon.h"

using namespace std;



int main() //Main function calling for constructors and other functions
{
    int o = 0;
    double s = 0;
    double c = 0;
    double u = 0;
    double perimeter = 0;
    //RegularPolygon polygon;
     RegularPolygon R();// First constructor called, provides a default palindrome with set length, number of sides, and coordinates.
     //cout << R << endl;
     RegularPolygon P(o, s); // Second Constructor, here the user inputs number of sides, and length for the sides.
     //cout << P << endl;
     RegularPolygon O(o, s, c, u); // Third constructor, here the user inputs the number of sides, length of sides, and x and y coordinates
     //cout << O << endl;
     //cout << R << endl;
      RegularPolygon.getPerimeter(); // This function was supposed to get the perimeter for the polygons, but i did not get it to work, i get an error saying: expected unqualified id, before '.' token
      // i do not know the reason for this error to appear, and id did could not solve it.

      RegularPolygon.getArea();
      //Here is supposed to be a function with the purpose to get the area from the polygons, but i am also getting similar errors.

     return 0;
}
