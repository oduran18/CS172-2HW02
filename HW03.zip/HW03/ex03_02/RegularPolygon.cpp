#include <iostream>
#include <cmath>
#include "RegularPolygon.h"

using namespace std;

RegularPolygon::RegularPolygon() //No argument constructor which sets the defaults for a polygon.
{
    n = 3;
    side = 1;
    x = 0;
    y = 0;
}

RegularPolygon::RegularPolygon(int& o, double& s) // Second constructor where the user inputs number of sides and length of sides.
{
    n = o; // This will allow me to use the private variables, declared on the private section of class.
    side = s;
    cout << "Please enter the number of sides for your first polygon polygon: "; // prompts the user to enter number of sides for polygon
    cin >> o;

    cout <<"\n";


    cout << "Please enter the side length of your first polygon. enter one number, which will be the the length of all the sides: "; // Prompts the user to enter length of sides of polygon
    cin >> s;

    cout << "\n";
}



RegularPolygon::RegularPolygon(int& t , double& d, double& c, double& u) // Third constructor, where the user enter number of sides, length of sides, and x and y coordinates.
{
    //n = t;
    //side = d;
    x = c;
    // Allows me to use x and y variables which are private in the class.
    y = u;
    cout << "\n";
    cout << "Please enter the number of sides for your second polygon: "; // prompts the user to enter number of sides for polygon
    cin >> t;

    cout <<"\n";


    cout << "Please enter the side length of your second polygon. enter one number, which will be the the length of all the sides: "; // Prompts the user to enter length of sides of polygon
    cin >> d;

    cout <<"\n";

    cout << "Please enter the x coordinate: "; // Prompts the user for x coordinate.
    cin >> c;

    cout << "\n";

    cout << "Please enter the y coordinate: "; // prompts the user for y coordinate.
    cin >> u;
}

int RegularPolygon.getPerimeter(int& o, double& s) //This function was to get the perimeter for the polygons
{
    n = o;
    side = s;
    int perimeter = s + o; // computes perimeter of polygon
    cout << "The perimeter of your polygon is: " << perimeter << endl;

    return perimeter;
    //Here i had trouble figuring out the error that i had on main.cpp because of this i could not go any further.
}

int RegularPolygon.getArea(int& 0, double& s) // This function gets the area of the polygon, but it is still in work, since there were some stuff i could not figure out.
{
    n = 0;
    side = s;
    double Area = 0;
    Area = (n* pow(s,2) /4* tan(theta/n)); // here i had issues figuring out how to use theta in c++
}
